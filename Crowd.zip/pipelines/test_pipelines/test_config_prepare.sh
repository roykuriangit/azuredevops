#!/bin/bash
# Kalai: Script to get crowd app version,userdetails and hostsni
echo "Total Arguments:" $#
if [ $# == 3 ]; then
	echo "Namespace =" ${1}
    echo "value Location =" ${2}
    echo "config Location =" ${3}
else
    echo "Your command line contains wrong number of arguments"
	exit 1
fi

K8S_NAMESPACE="${1}"
FILE_LOC="${2}"
test_config_file="${3}"
TEST_USER='admin'
TEST_PASS='admin'

crd_version=`cat ${FILE_LOC} | grep -w "tag:" | awk {'print $2'}`
echo ${crd_version}
crd_url=`cat ${FILE_LOC} | grep -w "hostSNI:" | awk {'print $2'}`
echo ${crd_url}
echo "crd_url:${crd_url}," >> ${test_config_file}
echo "username:${TEST_USER}," >> ${test_config_file}
echo "pass:${TEST_PASS}," >> ${test_config_file}
echo "crd_version:${crd_version}," >> ${test_config_file}

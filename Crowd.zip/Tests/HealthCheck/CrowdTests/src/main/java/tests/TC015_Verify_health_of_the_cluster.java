package tests;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import bases.baseMethods;

public class TC015_Verify_health_of_the_cluster extends baseMethods{

	
	@Test
	public void getNamespaceStatus()
	{
		 String s;
	      Process p;
	        try {
		 p = Runtime.getRuntime().exec("kubectl get pods -n '$(k_namespace)'");
         BufferedReader br = new BufferedReader(
             new InputStreamReader(p.getInputStream()));
         while ((s = br.readLine()) != null)
             System.out.println("line: " + s);
	
	} catch (Exception e) {}
}
}

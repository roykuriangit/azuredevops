function homePageElement()
{
    this.homePageTitle = element(by.xpath('//div[@class="aui-page-panel"]/div/section/h2'));
    this.applicationTab=  element(by.id('topnavBrowseApplication'));
    this.applicationTabTitle = element(by.xpath('//div[@class="aui-page-panel"]/div/section/h2'));
    this.usersTab=  element(by.id('topnavBrowseUsers'));
    this.usersTabTitle = element(by.xpath('//div[@class="aui-page-panel"]/div/section/h2'));
    this.groupsTab=  element(by.id('topnavBrowseGroups'));
    this.groupsTabTitle = element(by.xpath('//div[@class="aui-page-panel"]/div/section/h2'));
    this.directoryTab= element(by.id('topnavBrowseDirectory'));
    this.directoryTabTitle = element(by.xpath('//div[@class="aui-page-panel"]/div/section/h2'));
    this.auditLogTab=element(by.id('topnavBrowseAuditLog'));
    this.auditTabTitle = element(by.xpath('//h2/span'));
    this.adminTab = element(by.partialLinkText('Administration'));
    this.adminMenuOptionsAll = element.all(by.xpath('//div[@id="system-admin-menu-content"]/div/ul/li/a'));
      
}
 


module.exports = new homePageElement();

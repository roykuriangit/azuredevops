function loginPageElement()
{
    this.username = element(by.name('username'));
    this.password = element(by.name('password'));
    this.login= element(by.className('Button__StyledButton-sc-1o41kgk-0 jKCbTP'));
}

module.exports = new loginPageElement();

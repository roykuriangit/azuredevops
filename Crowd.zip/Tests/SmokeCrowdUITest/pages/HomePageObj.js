var HomepageObj = function() {
var EC=protractor.ExpectedConditions;
var setupCrowdButton = element(by.className('aui-button aui-button-primary'));
var setUpPageTitle =  element(by.xpath('//div[@class="aui-page-panel"]/div/section/h2[1]'));
     this.get =  function() {
         browser.get(url);
      };
    this.verifySetupCrowdPageTitle = function(){
        expect(setUpPageTitle.getText()).toEqual('Crowd — Identity management for web apps');
    };
   
    this.clickSetupCrowd =function() {
        setupCrowdButton.click();
    };

};

module.exports = new HomepageObj();
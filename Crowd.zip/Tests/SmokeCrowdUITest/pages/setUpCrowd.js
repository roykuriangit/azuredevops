function setUpCrowdPageElement()
{   this.setUpPageTitle = element(by.xpath('//div[@class="aui-page-panel"]/div/section/h2[1]'));
    this.setupCrowdButton = element(by.className('aui-button aui-button-primary'));
}

module.exports = new setUpCrowdPageElement();
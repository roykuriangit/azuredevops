var LoginPageObj = function() {

    var username = element(by.name('username'));
    var password = element(by.name('password'));
    var login = element(by.className('Button__StyledButton-sc-1o41kgk-0 jKCbTP'));

    this.enterUsername = function(){
        username.sendKeys(uname);
    };

    this.enterPasswrord= function(){
        password.sendKeys(pwd);
    };

    this.clickLogin = function(){
        login.click();
    };
    this.username = element(by.name('username'));
    this.password = element(by.name('password'));
    this.login = element(by.className('Button__StyledButton-sc-1o41kgk-0 jKCbTP'));
   


};

module.exports = new LoginPageObj();
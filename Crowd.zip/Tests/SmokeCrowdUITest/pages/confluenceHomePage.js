function confluenceHomePageElement()

{   this.userProfile = element(by.id('user-menu-link'));
    this.spacesTab = element(by.id('space-menu-link'));
   
}

module.exports = new confluenceHomePageElement();
var jasmineReporters = require('jasmine-reporters');
exports.config = {
       framework: 'jasmine2',
       capabilities: {
            directConnect: true,
        'browserName': 'firefox',
        chromeOptions: {
        args: [ "--headless", "--no-sandbox", "--window-size=1280,1480", "--disable-dev-shm-usage", "--disable-gpu"]
   },
        marionette: true,
          acceptInsecureCerts: true,
               },         
     specs: ['./Tests/TC001_Verify_Crowd_UI_is_Properly_Wired.js'],
    
    jasmineNodeOpts: {
        defaultTimeoutInterval: 30000
      },
    onPrepare : function(){
      jasmine.getEnv().addReporter(new jasmineReporters.JUnitXmlReporter({
        consolidateAll: true,
        filePrefix: 'TEST-RESULTS.xml'
        }));
        var fs = require("fs");
		    var rawContent = fs.readFileSync("./data/config.properties");
		    var urlApp = 'https://';
        var fullContent = rawContent.toString()
        var allPairs = fullContent.split(",");
        url = urlApp.concat(allPairs[4].split("crd_url:")[1]);
        uname = allPairs[5].split(":")[1];
        pwd = allPairs[6].split(":")[1];
         
      }
}
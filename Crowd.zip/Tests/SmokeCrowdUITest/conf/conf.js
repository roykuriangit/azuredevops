var jasmineReporters = require('jasmine-reporters');
exports.config = {
    directConnect: true,
    framework: 'jasmine2',
    capabilities: {
        'browserName': 'chrome', 
         chromeOptions: {
            useAutomationExtension: false
         //   args:[ "--headless", "--disable-gpu", "--window-size=800,600" ]
        }
       }
     ,

     specs: ['../Tests/SmokeUITestCrowd.js'],
    
    jasmineNodeOpts: {
        defaultTimeoutInterval: 300000
      },
    onPrepare : function(){
      jasmine.getEnv().addReporter(new jasmineReporters.JUnitXmlReporter({
        consolidateAll: true,
            savePath: 'testresults',
           filePrefix: 'TEST-RESULTS.xml'
        }));
        var fs = require("fs");
		var rawContent = fs.readFileSync("../data/config.properties");
		var propertyMap = {}
        var fullContent = rawContent.toString()
       console.log(fullContent);
        var allPairs = fullContent.split(",");
         url = allPairs[0].split("url:")[1];
         uname = allPairs[1].split(":")[1];
         pwd = allPairs[2].split(":")[1];
          console.log(url);
      }
}
const { browser } = require("protractor");
const homePage = require("../pages/homePage.js");
var setUpCrowdPage = require("../pages/setUpCrowd.js");
var loginPage = require("../pages/login.js");
var LoginPageObj = require('../pages/LoginPageObj.js');
var EC=protractor.ExpectedConditions;
beforeEach(function(){
    browser.waitForAngularEnabled(false);
    browser.get(url);
});

describe('smoke ui tests Crowd',function(){
     
 it('Verify if crowd ui is properly wired and is up and running', function(){
       console.log("Crowd UI Smoke Tests Started");
       browser.waitForAngularEnabled(false);
       browser.wait(EC.presenceOf(setUpCrowdPage.setupCrowdButton));
       expect(setUpCrowdPage.setUpPageTitle.getText()).toEqual('Crowd — Identity management for web apps');
       setUpCrowdPage.setupCrowdButton.click();
       browser.wait(EC.presenceOf(loginPage.username));
       loginPage.username.sendKeys(uname);
       browser.wait(EC.presenceOf(loginPage.password));
       loginPage.password.sendKeys(pwd);
       loginPage.login.click();
       browser.wait(EC.presenceOf(homePage.homePageTitle));
       expect(homePage.homePageTitle.getText()).toEqual('Welcome to the Crowd administration console');
       /*homePage.applicationTab.click();
       browser.wait(EC.presenceOf(homePage.applicationTabTitle));
       expect(homePage.applicationTabTitle.getText()).toEqual('Applications');
       homePage.usersTab.click();
       browser.wait(EC.presenceOf(homePage.usersTab));
        expect(homePage.usersTabTitle.getText()).toEqual('Users');
        homePage.groupsTab.click();
        browser.wait(EC.presenceOf(homePage.groupsTabTitle));
        expect(homePage.groupsTabTitle.getText()).toEqual('Groups');
        homePage.directoryTab.click();
        browser.wait(EC.presenceOf(homePage.directoryTabTitle));
        expect(homePage.directoryTabTitle.getText()).toEqual('Directories');
        homePage.auditLogTab.click();
        browser.wait(EC.presenceOf(homePage.auditTabTitle));
        expect(homePage.auditTabTitle.getText()).toEqual('Audit log');*/
        homePage.adminTab.click();
        homePage.adminMenuOptionsAll.getText().then(function(menus) {
            expect(menus.length).toBe(17);
            expect(menus[0]).toBe('General');
            
                      
        });
       
        

 });});
const { browser } = require("protractor");
const homePage = require("../pages/homePage.js");

describe('Integration tests of Crowd with Confluence',function(){
    var setUpCrowdPage = require("../pages/setUpCrowd.js");
    var loginPage = require("../pages/login.js");
    var confluenceHomePage = require("../pages/confluenceHomePage.js");
    var EC=protractor.ExpectedConditions;
    beforeEach(function(){
        browser.waitForAngularEnabled(false);
        browser.get(url);
    });
 it('Verify if we are logged in Crowd and try to access Confluence then user is logged in', function(){
       
       browser.waitForAngularEnabled(false);
       browser.wait(EC.presenceOf(setUpCrowdPage.setupCrowdButton));
       expect(setUpCrowdPage.setUpPageTitle.getText()).toEqual('Crowd — Identity management for web apps');
        setUpCrowdPage.setupCrowdButton.click();
        browser.wait(EC.presenceOf(loginPage.username));
        loginPage.username.sendKeys(uname);
        browser.wait(EC.presenceOf(loginPage.password));
        loginPage.password.sendKeys(pwd);
        loginPage.login.click();
        browser.wait(EC.presenceOf(homePage.homePageTitle));
        expect(homePage.homePageTitle.getText()).toEqual('Welcome to the Crowd administration console');
        browser.get("https://uat.confluence.npd.axaxl.app/");
        browser.wait(EC.presenceOf(confluenceHomePage.spacesTab));
        expect(confluenceHomePage.userProfile.getAttribute('data-username')).toEqual(uname);
        
   

 });});
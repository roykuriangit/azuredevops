package utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadUsers {

public static String[] readUserName(String fileName) throws IOException {
		
		
	    XSSFWorkbook wb = new XSSFWorkbook(fileName); 
	    XSSFSheet ws = wb.getSheet("Users");
		int rowsCount = ws.getLastRowNum();
		String[] data = new String[rowsCount];
		for (int i = 1; i <= rowsCount; i++) {
		
			XSSFCell cell =  ws.getRow(i).getCell(0);
				data[i - 1]= String.valueOf(cell.getStringCellValue());
			  
		}
		wb.close();
		return data;
	}

}

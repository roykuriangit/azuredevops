package utils;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadManagedDirectory {
	
public static List<String> getManagedDirectory(String fileName) throws IOException {
		
		List<String> directoryNames = new LinkedList<String>();
	    XSSFWorkbook wb = new XSSFWorkbook(fileName); 
	    XSSFSheet ws = wb.getSheet("ManagedDirectory");
		int rowsCount = ws.getLastRowNum();
		
		for (int i = 1; i <= rowsCount; i++) {
		
			XSSFCell cell =  ws.getRow(i).getCell(0);
			directoryNames.add(String.valueOf(cell.getStringCellValue()));
			  
		}
		wb.close();
		return directoryNames ;
	}

}

package pages;

public class Administration {

}

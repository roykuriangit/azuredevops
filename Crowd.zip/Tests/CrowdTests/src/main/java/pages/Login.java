package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import bases.baseMethods;


public class Login extends baseMethods{
	
	
	
	public Login enterUsername() {
		 WebDriverWait wait = new WebDriverWait(driver, 60000);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
		enterValue(locateElement("name","username"),username);
		return this;
		
	}
	public Login enterPassword() {
		 WebDriverWait wait = new WebDriverWait(driver, 60000);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("password")));
		enterValue(locateElement("name","password"),password);
		return this;
		
	}
	
	public Home clickLogin() {
		 WebDriverWait wait = new WebDriverWait(driver, 60000);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));
		click(locateElement("xpath","//button[@type='submit']"));
		return new Home();
		
	}
}

package pages;



import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import bases.baseMethods;

public class SetupCrowd extends baseMethods {
	
	
	public Login clickSetupCrowd()
	{
		 WebDriverWait wait = new WebDriverWait(driver, 60000);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Set up Crowd")));
		click(locateElement("link","Set up Crowd"));
		
		return new Login();
	
		
	}

	

}

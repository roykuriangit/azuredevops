package pages;

import bases.baseMethods;

public class Home extends baseMethods {
	
	public Home clickApplications() {
		click(locateElement("link","Applications"));
		return this;
	}
	
	public Home clickUsers() {
		click(locateElement("link","Users"));
		return this;
	}
	public Home clickGroups() {
		click(locateElement("link","Groups"));
		return this;
	}
	
	public Home clickDirectories() {
		click(locateElement("link","Directories"));
		return this;
	}
	
	public Home clickAuditLog() {
		click(locateElement("link","Audit log"));
		return this;
	}

}

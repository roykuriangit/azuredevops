package design;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;

public interface Browser {
	
	public WebDriver startApp() throws IOException;
	public WebElement locateElement(String locatorType, String value);
	public void close();

}

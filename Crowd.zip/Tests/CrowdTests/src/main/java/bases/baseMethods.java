package bases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import design.Browser;
import design.Element;
import utils.ReadApplnIdDirectoryName;
import utils.ReadSqlandCount;
import utils.ReadUsers;

public class baseMethods  implements Browser,Element {
	public static  WebDriver driver;
	public  static String  fileName;
	public WebDriverWait wait;
	public static List<String> pluginsPresent;
	
	public static String url,username,password,node_total,Health,Phase,Version,chromeDriverPath;
	Properties configData = new Properties();
    
	@BeforeSuite
	public void getConfigData() throws IOException
	{
		Properties configData = new Properties();
		FileInputStream in = new FileInputStream( "./src/main/resources/config.properties");
		configData.load(in);
	    url = ("https://"+configData.getProperty("crd_url")+"/").replace(",", "");
	    username = (configData.getProperty("username")).replace(",", "");
	    password = (configData.getProperty("pass")).replace(",", "");
	   //node_total =(configData.getProperty("node_total")).replace(",", "");
	   //Health =(configData.getProperty("Health")).replace(",", "");
	   //Phase =(configData.getProperty("Phase")).replace(",", "");
	    Version =(configData.getProperty("crd_version")).replace(",", "");
	   // chromeDriverPath= configData.getProperty("chromeDriverPath");
	}

	@DataProvider(name="ReadSqlandCountTestData")	
	public String[][] sendSqlandCountData() throws IOException
	{
		return ReadSqlandCount.readSqlandCount(fileName);
	}
	
	@DataProvider(name="ReadApplnIdDirectoryName")	
	public String[][] sendApplnIdDirectoryName() throws IOException
	{
		return ReadApplnIdDirectoryName.readApplnIdDirectoryName(fileName);
	}
	
	@DataProvider(name="ReadUsernameData")	
	public String[] sendUserName() throws IOException
	{
		return ReadUsers.readUserName(fileName);
	}
	
	public WebDriver startApp() throws IOException {
					
			
			System.setProperty("webdriver.chrome.driver", chromeDriverPath);
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--headless");
			//options.addArguments("--no-sandbox");
			//options.addArguments("--disable-dev-shm-usage");
			options.setExperimentalOption("useAutomationExtension", false);
			driver = new ChromeDriver(options); 
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get(url);
			driver.manage().window().maximize();
			return driver;
	}
	
	public WebElement locateElement(String locatorType, String value) {
		try
		{
			switch(locatorType.toLowerCase()) {
			case "id" : return driver.findElement(By.id(value));
			case "name" : return driver.findElement(By.name(value));
			case "class" : return driver.findElement(By.className(value));
			case "link" : return driver.findElement(By.linkText(value));
			case "xpath" : return driver.findElement(By.xpath(value));
			case "partialLink" : return driver.findElement(By.partialLinkText(value));
			}
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
		
	}
	public void close() {
		driver.close();
	}
	
	public void enterValue(WebElement ele, String data) {
		
		ele.sendKeys(data);
	}
	public void click(WebElement ele) {
		try
		{
			ele.click();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	

	
	
	
	

}

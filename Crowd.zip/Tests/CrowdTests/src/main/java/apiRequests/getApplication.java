package apiRequests;

import static io.restassured.RestAssured.given;

import bases.baseMethods;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class getApplication extends baseMethods {
	
	public Response getApplicationRequest(String url,String username,String password) {
		RestAssured.baseURI= url;
		Response response = null;
		response = given().auth().preemptive().basic(username, password)
		.relaxedHTTPSValidation()
		.when()
		.get("crowd/rest/admin/1.0/application").then().assertThat().statusCode(200).extract().response();
   		return response;
	}

}

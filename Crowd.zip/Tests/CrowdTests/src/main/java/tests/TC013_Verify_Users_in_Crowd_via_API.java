package tests;

import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import apiRequests.getUsers;
import bases.baseMethods;
import io.restassured.response.Response;
import io.restassured.path.xml.XmlPath;

public class TC013_Verify_Users_in_Crowd_via_API extends baseMethods {
	
Response response;
	

@BeforeTest
public void setFileName(){
	
	if(baseMethods.url.contains("uat")) {
		baseMethods.fileName="./data/NpdTestData.xlsx";
}
	else if (baseMethods.url.contains("prd"))
	{
		baseMethods.fileName="./data/PrdTestData.xlsx";
	}
}
	
	
	public  static Response callAPI(String uName) throws IOException
	{
		
		String url = baseMethods.url;
		String username = "api_user";
		String password = "api_user";
		Response response = new getUsers()
				.getUsersRequest(url, username, password,uName);
				
		return response;
	}
	
	@Test(dataProvider ="ReadUsernameData")
	public void verifySampleUsersViaApi(String uName) 
	{
		
	    try {
			response = callAPI(uName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		XmlPath xmlPath = new XmlPath(response.asString());
		Assert.assertTrue(xmlPath.getBoolean("user.active"));
		
		
		
	}


}

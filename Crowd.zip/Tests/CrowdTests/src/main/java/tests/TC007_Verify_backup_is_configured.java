package tests;

import java.io.IOException;


import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import apiRequests.getBackupConfiguration;
import bases.baseMethods;
import io.restassured.response.Response;
import junit.framework.Assert;

public class TC007_Verify_backup_is_configured extends baseMethods {
   Response response;
	@BeforeTest
	public  Response callAPI() throws IOException
	{
		
		String url = baseMethods.url;
		String username = baseMethods.username;
		String password = baseMethods.password;
		Response response = new getBackupConfiguration()
				.getBackupConfigurationRequest(url, username, password);
				
		return response;
	}
	
	@Test
	public void verifyBackupConfiguration() 
	{
		
	    try {
			response = callAPI();
		} catch (IOException e) {
			e.printStackTrace();
		}
		JSONObject obj = new JSONObject(response.asString());
		Boolean scheduledBackupEnabled = obj.getBoolean("scheduledBackupEnabled");
		Assert.assertTrue(scheduledBackupEnabled);
	   	
	}
}

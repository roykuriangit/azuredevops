package tests;

import java.io.IOException;

import org.junit.Assert;
import org.testng.annotations.Test;

import bases.baseMethods;

public class TC012_Verify_version_of_the_operator extends baseMethods {

	@Test
	public void verifyVersionofCluster() throws IOException {
		
		String Version = baseMethods.Version;
		Assert.assertEquals("Version is "+ (String) Version ,"4.0.2",Version.trim());
		
	}
}

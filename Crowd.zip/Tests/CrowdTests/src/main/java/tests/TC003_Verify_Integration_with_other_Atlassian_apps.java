package tests;

public class TC003_Verify_Integration_with_other_Atlassian_apps {

}

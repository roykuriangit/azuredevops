package tests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import apiRequests.getGroups;
import bases.baseMethods;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class TC014_Verify_Groups_in_Crowd_via_API extends baseMethods {
	
Response response;
	

@BeforeTest
public void setFileName(){
	
	if(baseMethods.url.contains("uat")) {
		baseMethods.fileName="./data/NpdTestData.xlsx";
}
	else if (baseMethods.url.contains("prd"))
	{
		baseMethods.fileName="./data/PrdTestData.xlsx";
	}
}
	
	
	public  static Response callAPI(String uName) throws IOException
	{
		
		String url = baseMethods.url;
		String username = "api_user";
		String password = "api_user";
		Response response = new getGroups()
				.getGroupsRequest(url, username, password,uName);
				
		return response;
	}
	
	@Test(dataProvider ="ReadUsernameData")
	public void verifyGroupsofUsersViaApi(String uName) 
	{
		
	    try {
			response = callAPI(uName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		XmlPath xmlPath = new XmlPath(response.asString());
		Assert.assertEquals(xmlPath.getList("groups").size(), 1);
		
		
		
		
	}


}

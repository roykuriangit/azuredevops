package tests;

import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import apiRequests.getDirectoryMapping;
import bases.baseMethods;
import io.restassured.response.Response;

public class TC009_Verify_Directory_Mapping_for_Each_application extends baseMethods {
	
	 Response response;
		@BeforeTest
		public  void setfilename()
		{
			
			if(baseMethods.url.contains("uat")) {
				baseMethods.fileName="./data/NpdTestData.xlsx";}
		
			else if (baseMethods.url.contains("prd"))
			{
				baseMethods.fileName="./data/PrdTestData.xlsx";
			}
		}
		public Response callApi(String id) {
			
			String username = baseMethods.username;
			String password = baseMethods.password;
			Response response = new getDirectoryMapping()
					.getDirectoryMappingRequest(url, username, password,id);
					
			return response;
		}
		
		@Test(dataProvider="ReadApplnIdDirectoryName")
		public void verifyManagedDirectories(String id,String directory) throws IOException 
		{
			String[] directoryName = directory.split(",");
			int arrSize =directoryName.length;
			int matchCount = 0;
		    response = callApi(id);
			JSONObject obj = new JSONObject(response.asString());
			int size = obj.getInt("size");
			JSONArray arrayResp = obj.getJSONArray("values");
			//System.out.println(arrSize);
			//System.out.println(size);
			Assert.assertEquals(arrSize, size);
			for (int i=0;i<arrayResp.length();i++) {
				
		    	String directoryNames = arrayResp.getJSONObject(i).getString("name");
		    	if(directoryNames.trim().equalsIgnoreCase(directoryName[i].trim()))
		    	{
		    		matchCount++;
		    	}
		    	
		    	
		    
			}
			
		}

}

package tests;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import apiRequests.getApplication;
import bases.baseMethods;
import io.restassured.response.Response;
import utils.ReadApplication;


public class TC006_Verify_Application_in_Crowd extends baseMethods {
	
Response response;
String filename;
List<String> appNameFromAPI;
	
	@BeforeTest
	public  Response callAPI() throws IOException
	{
		
		String url = baseMethods.url;
		String username = baseMethods.username;
		String password = baseMethods.password;
		Response response = new getApplication()
				.getApplicationRequest(url, username, password);
				
		return response;
	}
	
	@Test
	public void getApplicationDetailsCrowd() 
	{
		
	    try {
			response = callAPI();
		} catch (IOException e) {
			e.printStackTrace();
		}
		JSONObject obj = new JSONObject(response.asString());
		int applnSize = obj.getInt("size");
		Assert.assertEquals(applnSize, 18);
	    JSONArray arrayResp = obj.getJSONArray("values");
	    appNameFromAPI= new LinkedList<String>();
	    for (int i=0;i<arrayResp.length();i++) {
	    	String appName = arrayResp.getJSONObject(i).getString("name");
	    	appNameFromAPI.add(appName);
	    	//Boolean active = arrayResp.getJSONObject(i).getBoolean("active");
	    	//System.out.println(appName);
	    	//System.out.println(active);
	    	
	    }
	   }
	   	
	    @AfterMethod
		public void verifyApplicationinCrowd() throws IOException
		{
	    	String url = baseMethods.url;
	    	if(url.contains("uat")) {
	    	fileName="./data/NpdTestData.xlsx";
	    }
	    	else if (url.contains("prd"))
	    	{
	    		fileName="./data/PrdTestData.xlsx";
	    	}
	    	
	    	List<String> applnNamesFromCrowd = ReadApplication.getApplications(fileName);
	    	int applnNamesFromCrowdSize = applnNamesFromCrowd.size();
	    	int matchCount = 0 ;
	    	for(int i=0;i<appNameFromAPI.size();i++) {
				for(int j=0;j<applnNamesFromCrowd.size();j++) {
					if(applnNamesFromCrowd.get(j).equalsIgnoreCase(appNameFromAPI.get(i))){
						matchCount++;
						
								}
					
	    	}
				
	   	  	
		
	    }
	    	
	    	Assert.assertEquals(applnNamesFromCrowdSize, matchCount, "All the application exists");
		}
}



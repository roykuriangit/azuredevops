package tests;

import java.io.IOException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import bases.baseMethods;
import pages.SetupCrowd;


public class TC002_Verify_Crowd_application_is_properly_wired_up extends baseMethods{
	
	@BeforeClass
	public void beforeMethod() throws IOException, InterruptedException
	{
		
		driver = startApp(); 
		
	}
	@AfterMethod
	public void afterMethod()
	{
		close();
	}
	
	@Test
	public void verifyCrowdApplicationIsProperlyWired() throws InterruptedException
	{
		
		new SetupCrowd()
		.clickSetupCrowd()
		.enterUsername();
		/*.enterPassword()
		.clickLogin()
		.clickApplications()
		.clickUsers()
		.clickGroups()
		.clickDirectories()
		.clickAuditLog();*/
		
		
		
		
	}

}

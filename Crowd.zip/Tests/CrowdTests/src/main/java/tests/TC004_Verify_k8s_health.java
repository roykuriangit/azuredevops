package tests;

import java.io.IOException;

import org.junit.Assert;
import org.testng.annotations.Test;

import bases.baseMethods;

public class TC004_Verify_k8s_health extends baseMethods {
	
	@Test
	public void verifyKubernetesClusterHealthTobeGreen() throws IOException {
		String Health = baseMethods.Health;
		Assert.assertEquals("K8S Cluster Status is green", "green",Health.trim());

}

}

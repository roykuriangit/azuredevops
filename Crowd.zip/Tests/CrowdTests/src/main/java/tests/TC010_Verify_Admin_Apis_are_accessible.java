package tests;

import java.io.IOException;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;


import apiRequests.getServerInfo;
import bases.baseMethods;
import io.restassured.response.Response;

public class TC010_Verify_Admin_Apis_are_accessible  extends baseMethods{
	Response response;
	
	public static Response callApi() throws IOException
	{	
		
		Response response = new getServerInfo()
		.getServerInfoRequest(url, username, password);
		return response;
	}
	
	@Test
	public void smokeAPITest() throws IOException 
	{
		
	    response = callApi();
		JSONObject obj = new JSONObject(response.asString());
		String versionFromAPI = obj.getString("version");
		String deploymentTitle = obj.getString("deploymentTitle");
		Assert.assertEquals(versionFromAPI, "4.0.3");	
		Assert.assertEquals(deploymentTitle, "XL Catlin Crowd");	  
	    
		}
	}



package tests;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.json.JSONObject;
import org.json.JSONArray;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import apiRequests.getManagedDirectories;
import bases.baseMethods;
import io.restassured.response.Response;
import utils.ReadManagedDirectory;

public class TC008_Verify_mapped_directories_of_crowd extends baseMethods {
	
	 Response response;
	 String filename;
	 List<String> dirNameFromAPI = new LinkedList<String>();;
	 
		@BeforeTest
		public  void getDirectoryMappingforAppln() throws IOException
		{
			
			String url = baseMethods.url;
			String username = baseMethods.username;
			String password = baseMethods.password;
		    response = new getManagedDirectories()
					.getManagedDirectoriesRequest(url, username, password);
           JSONObject obj = new JSONObject(response.asString());
			
			JSONArray arrayResp = obj.getJSONArray("values");
			
			for (int i=0;i<arrayResp.length();i++) {
		    	String directoryName = arrayResp.getJSONObject(i).getString("displayName");
		    	dirNameFromAPI.add(directoryName);
		    	
		    }
					
			
		}
		
		@Test
		public void verifyDirectoryMappingforAppln() throws IOException
		{
		  
		   	String url = baseMethods.url;
		    	if(url.contains("uat")) {
		    	fileName="./data/NpdTestData.xlsx";
		    }
		    	else if (url.contains("prd"))
		    	{
		    		fileName="./data/PrdTestData.xlsx";
		    	}
		    	
		    	List<String> dirNamesFromCrowd = ReadManagedDirectory.getManagedDirectory(fileName);
		    	int dirNamesFromCrowdSize = dirNamesFromCrowd.size();
		    	int dirNameFromAPISize = dirNameFromAPI.size();
		    	int matchCount = 0 ;
		    	
		    	for(int i=0;i<dirNameFromAPI.size();i++) {
					for(int j=0;j<dirNamesFromCrowd.size();j++) {
						String testDataValue = dirNamesFromCrowd.get(j).trim();
						String apiValue =  dirNameFromAPI.get(i).trim();
						
						if(apiValue.equalsIgnoreCase(testDataValue)){
							
                         
							matchCount++;
							
									}
						
						
		    	}
					
		   	  	
			
		    }
		    	
		    	Assert.assertEquals(dirNamesFromCrowdSize, dirNameFromAPISize);
			}
}

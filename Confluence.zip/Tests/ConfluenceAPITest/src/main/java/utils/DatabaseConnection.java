package utils;

import java.io.FileInputStream;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;


import com.microsoft.sqlserver.jdbc.SQLServerException;

public class DatabaseConnection {


	public static Connection databaseConnect() throws IOException, SQLServerException
	{
		Properties configData = new Properties();
		FileInputStream in = new FileInputStream( "./src/main/resources/config.properties");
		configData.load(in);
		String hostName = (configData.getProperty("DB_SERVER").trim()).replace(",", "").concat(".database.windows.net");
		String dbName = (configData.getProperty("DB_NAME").trim()).replace(",", "");
		String user = (configData.getProperty("DB_USERNAME").trim()).replace(",", "");
		String password = (configData.getProperty("DB_PASS").trim()).replace(",", "");
	 //azure sql
		String url = String.format("jdbc:sqlserver://%s:1433;database=%s;user=%s;password=%s;encrypt=true;"
       + "hostNameInCertificate=*.database.windows.net;loginTimeout=30;", hostName, dbName, user, password);
		Connection connection = null;
    try {
        connection = DriverManager.getConnection(url);
      }
    catch (Exception e) {
        e.printStackTrace();
    }
	return connection;
	
		//on Prem Connection
		/*
		SQLServerDataSource ds = new SQLServerDataSource();  
		ds.setUser(user);  
		ds.setPassword(password);  
		ds.setServerName(hostName);  
		ds.setPortNumber(1433);
		ds.setDatabaseName(dbName);  
		Connection con = ds.getConnection();  
		return con;*/
}
}
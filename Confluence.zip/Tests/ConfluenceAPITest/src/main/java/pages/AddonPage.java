package pages;

import java.util.LinkedList;
import java.util.List;
import org.openqa.selenium.WebElement;
import bases.baseMethods;
import bases.baseMethodsUi;

public class AddonPage extends baseMethodsUi{
	
	
	public AddonPage goToSystemAddon()
	{
		String Url = baseMethods.url+"plugins/servlet/upm/manage/system";
		driver.navigate().to(Url);		
		return this;
		
	}
	
	public AddonPage getUserInstalledAddonCount()
	{
		List<WebElement> getUserPlugins = driver.findElementsByXPath("//div[@id='upm-manage-user-installed-plugins']/div/div/div[@class='upm-plugin user-installed']");
		int userPluginsCount = getUserPlugins.size();
		System.out.println(userPluginsCount);
		return this;
	}
	
	public AddonPage getSystemInstalledAddonCount()
	{
		List<WebElement> getSystemPlugins = driver.findElementsByXPath("//div[@id='upm-manage-system-plugins']/div/div/div");
		int systemsPluginsCount = getSystemPlugins.size();
		System.out.println(systemsPluginsCount);
		return this;
	}
	public AddonPage getUserInstalledAddons()
	{
		
		List<WebElement> getUserPlugins = driver.findElementsByXPath("//div[@id='upm-manage-user-installed-plugins']/div/div/div[@class='upm-plugin user-installed']");
		pluginsPresent = new LinkedList<String>();
		for(int i=1;i<=getUserPlugins.size();i++)
			{
			String userPluginName = driver.findElementByXPath("//div[@id='upm-manage-user-installed-plugins']/div/div/div[@class='upm-plugin user-installed'][" +i+ "]//div/h4").getText();
		
				pluginsPresent.add(userPluginName);
			}
			return this;
	
		
	}
	
	public AddonPage getSystemInstalledAddons()
	{
		//List<WebElement> getSysPlugins = driver.findElementsByXPath("//div[@id='upm-manage-system-plugins']/div/div/div");
		List<WebElement> getSysPlugins = driver.findElementsByXPath("//div[@class='upm-manage-plugin-list']/div/div");
		pluginsPresent = new LinkedList<String>();
		for(int i=1;i<=getSysPlugins.size();i++)
			{
			//String sysPluginName = driver.findElementByXPath("//div[@id='upm-manage-system-plugins']/div/div/div[" +i+ "]//div/h4").getText();
			String sysPluginName = driver.findElementByXPath("//div[@class='upm-manage-plugin-list']/div/div[" +i+ "]/div/h4").getText();
				pluginsPresent.add(sysPluginName);
			}
			
		return this;
	}
	
	
	
}

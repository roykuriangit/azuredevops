package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import bases.baseMethods;


public class BambooPage  extends baseMethods{
	
	private RemoteWebDriver driver;

	public BambooPage(RemoteWebDriver driver) {
		this.driver = driver;
	}

	public BambooPage getCurrentUrl()
	{
	    String url = driver.getCurrentUrl();
	   if(url.contains("DIRREP-FBPR"))
	   {
	   
		System.out.println("Bamboo page is loaded");
	   }
		
		return this;
	}
	
	


}

package pages;



import bases.baseMethods;

public class LoginPage extends baseMethods{
	
	public LoginPage enterUserName(String username) {
		
		enterValue(locateElement("id","os_username"),username);
		return this;
		}
	public LoginPage enterPassword(String password) {
		
		enterValue(locateElement("id","os_password"),password);
		return this;
		}
	public HomePage clickLogin() {
		click(locateElement("id","loginButton"));
		return new HomePage();
		}
	
	


}

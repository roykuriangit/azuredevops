package pages;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import bases.baseMethods;

public class SpacePage extends baseMethods{
	public static List<String> SpacesName;

	public SpacePage clickAllSpaces() throws InterruptedException
	{
	   click(locateElement("class","all-spaces"));
		Thread.sleep(10000);
		return this;
		
	}
	
public List<String> getSpaceName() throws InterruptedException {
	SpacesName = new LinkedList<String>();
	List<WebElement> getNoofPages = driver.findElementsByXPath("//ol[@class='aui-nav aui-nav-pagination']/li"); 
	int getPagesCount = getNoofPages.size();
	for (int i=2;i<=getPagesCount;i++)
	{
	 //click(locateElement("xpath","//div[@class='pagination']/ul/li["+i+"]"));--old uat
		click(locateElement("xpath","//ol[@class='aui-nav aui-nav-pagination']/li["+i+"]"));
	 Thread.sleep(10000);
	 List<WebElement> getSpace = driver.findElementsByXPath("//tr[@class='space-list-item']");
	 for(int j=1;j<=getSpace.size();j++) {
		//String spaceName = driver.findElementByXPath("//tr[@class='space-list-item']["+j+"]").getText();
		 String spaceName = driver.findElementByXPath("//tr[@class='space-list-item']["+j+"]/td[@class='entity-attribute space-name']/a").getText();
		 SpacesName.add(spaceName);
	}
	}
	//System.out.println(SpacesName.size());
	//System.out.println(SpacesName);
	return SpacesName;
	
}

public SpacePage searchSpace(String spaceName) throws InterruptedException
{
	driver.findElementByXPath("//input[@id='space-search-query']").sendKeys(spaceName,Keys.ENTER,Keys.ENTER);
	Thread.sleep(1000);
	return this;
	
}

public SpacePage clickSpace(String spaceName)
{
	//driver.findElementByXPath("//td[@class='entity-attribute space-name']/a[contains (text(),'"+spaceName+"')]").click();
    driver.findElementByXPath("//div[@class='search-results-container']/ol/li/h3/a/strong[contains (text(),'"+spaceName+"')]").click();
	return this;
	
}

public SpacePage clickChildPage(String childPageName) {
	
		click(locateElement("xpath","//div[@class='plugin_pagetree_children_content']/span/a[contains (text(),'"+childPageName+"')]"));
	driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
	return this;
}


public SpacePage verifyPageContent(String content) throws InterruptedException {
		List<WebElement> contentParagraph = driver.findElementsByXPath("//div[@id=\"main-content\"]/p");
	for(int i= 1;i<contentParagraph.size();i++) {
		String contentPara= contentParagraph.get(i).getText();
		if(contentPara.equalsIgnoreCase(content)) {
			System.out.println("Sample content verification is successfull");
			break;
		}
	}
	return this;
}

public JiraPage clickJiraIssue()
{   click(locateElement("xpath","//div/table/tbody/tr/td/a[contains (text(),'TEST-8561')]"));
	return new JiraPage(driver);
	
}

public BambooPage clickBamboolink()
{   click(locateElement("xpath","//div[@class='table-wrap build-diff']/table/tbody/tr/td/a[contains (text(),'DIRREP-FBPR')]"));
	return new BambooPage(driver);
	
}
}
	
	 
	
	
	


package pages;



import bases.baseMethodsUi;

public class HomePage extends baseMethodsUi{
	
	public HomePage clickAdmin() {
		click(locateElement("id","admin-menu-link"));
		return this;
		}
	
	public Authenticate clickAddon() {
		click(locateElement("xpath","//div[@class='aui-dropdown2-section']/ul/li/a[@id='plugin-administration-link']"));
		return new Authenticate();
	}
	
	public HomePage clickSpaces() {
		click(locateElement("id","space-menu-link"));
		return this;
		}
	
	public SpacePage clickSpaceDirectory() {
		click(locateElement("id","view-all-spaces-link"));
		return new SpacePage();
		}

	public Authenticate clickConfluenceAdmin() {
		click(locateElement("id","administration-link"));
		return new Authenticate();
		}
	
		
	
	
		
	}



package pages;

import org.junit.Assert;

import bases.baseMethods;

public class ConfluenceAdminPage extends baseMethods{
	
	public ConfluenceAdminPage clickBackupAdmin() {
		click(locateElement("link","Backup Administration"));
		return this;
		}
	
	public ConfluenceAdminPage verifyBackupEnabled() {
		String enabled = locateElement("id","dailyBackupStatus").getText();
		Assert.assertEquals(enabled, "Enabled");
		return this;
		
	}
	
	public ConfluenceAdminPage clickApplicationLink() {
		click(locateElement("link","Application Links"));
		return this;
		}

	public ConfluenceAdminPage getIntegrationDetails() {
		String catlinJira = locateElement("xpath","//tbody[@id='applicationsList']/tr[1]/td[@headers='name']").getText();
		String xlStarJira = locateElement("xpath","//tbody[@id='applicationsList']/tr[2]/td[@headers='name']").getText();
		Assert.assertEquals(catlinJira, "Catlin");
		Assert.assertEquals(xlStarJira, "XL STAR");
		return this;
	}
}

package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import bases.baseMethods;
import junit.framework.Assert;

public class JiraPage extends baseMethods{
	
	private RemoteWebDriver driver;

	public JiraPage(RemoteWebDriver driver) {
		this.driver = driver;
	}

	public JiraPage getCurrentUrl()
	{
	    String url = driver.getCurrentUrl();
	   if(url.contains("TEST-8561"))
	   {
	   
		System.out.println("Jira issue page is loaded");
	   }
		
		return this;
	}
	
	public JiraPage verifyLoggedin()
	{
		String loginCheck = getText(driver.findElementByXPath("(//div[@id='user-options-content']/div[@class='aui-dropdown2-section']/ul[@id='system']/li)[2]"));
		Assert.assertEquals(loginCheck, "Log Out" );
		return this;
	}

}

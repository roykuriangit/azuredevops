package pages;



import bases.baseMethodsUi;

public class Authenticate extends baseMethodsUi {
	
	public Authenticate enterPassword(String password) {
		
		enterValue(locateElement("id","password"),password);
		return this;
		}
  public AddonPage  clickConfirm() {
	    
		click(locateElement("id","authenticateButton"));
		return new AddonPage();
		}

  public ConfluenceAdminPage  clickConfirmtoConfluenceAdmin() {
	    
		click(locateElement("id","authenticateButton"));
		return new ConfluenceAdminPage();
		}
  
  
}

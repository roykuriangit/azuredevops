package tests;

import org.testng.annotations.Test;

import bases.baseMethods;
import pages.LoginPage;

public class TC003_Verify_Backup_and_restore_is_enabled extends baseMethods {

	
	@Test
	public void verifyBackupRestoreEnabled()
	{
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickAdmin()
		.clickConfluenceAdmin()
		.enterPassword(password)
		.clickConfirmtoConfluenceAdmin()
		.clickBackupAdmin()
		.verifyBackupEnabled();
					}
	
	
}

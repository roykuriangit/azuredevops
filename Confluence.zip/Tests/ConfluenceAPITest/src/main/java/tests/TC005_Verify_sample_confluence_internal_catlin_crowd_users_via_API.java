package tests;

import java.io.IOException;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import apiRequests.getUsers;
import bases.baseMethods;
import io.restassured.response.Response;
import junit.framework.Assert;

public class TC005_Verify_sample_confluence_internal_catlin_crowd_users_via_API extends baseMethods {
	Response response;
	@BeforeTest
	public void setFileNameLocation() throws IOException {
	
	String url = baseMethods.url;
	if((url.contains("uat"))||(url.contains("dev"))){
	fileName="./data/NpdTestData.xlsx";
}
	else if (url.contains("prd"))
	{
		fileName="./data/PrdTestData.xlsx";
	}
	}	

	public static Response callGetUsersApi(String uname) throws IOException
	{
		

		String url = baseMethods.url;
		String username = baseMethods.username;
		String password = baseMethods.password;
		Response response = new getUsers()
		.getUsersRequest(url, username, password,uname);
		return response;
	}
	
	@Test(dataProvider ="ReadUsersTestData")
	public void verifyUsersExists(String uname,String type) throws InterruptedException
	
	{
		 try {
				response = callGetUsersApi(uname);
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			String responseOutput = response.asString();
	   	    JSONObject obj = new JSONObject(responseOutput);
	        Assert.assertEquals(obj.getString("username"),uname);
	
	}
}
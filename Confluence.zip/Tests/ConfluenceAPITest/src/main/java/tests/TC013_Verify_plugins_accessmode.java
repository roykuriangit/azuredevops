package tests;

import java.io.IOException;
import org.testng.annotations.Test;
import apiRequests.getAccessMode;
import bases.baseMethods;
import io.restassured.response.Response;
import junit.framework.Assert;

public class TC013_Verify_plugins_accessmode  extends baseMethods{
	
	Response response;

	public static Response callGetAccessModeApi() throws IOException
	{
		String url = baseMethods.url;
		String username = baseMethods.username;
		String password = baseMethods.password;
		Response response = new getAccessMode()
		.getAccessModeRequest(url, username, password);
		return response;
	}
	
	@Test
	public void verifyPluginAccessMode() throws InterruptedException
	
	{
		 try {
				response = callGetAccessModeApi();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			String responseOutput = response.asString();
	   	    Assert.assertEquals(responseOutput,"\"READ_WRITE\"");
	        
	
	}

}

package tests;

import java.io.IOException;

import org.junit.Assert;
import org.testng.annotations.Test;

import bases.baseMethods;

public class TC015_Verify_version_of_the_cluster extends baseMethods {

	@Test
	public void verifyVersionofCluster() throws IOException {
		
		String Version = baseMethods.Version;
		Assert.assertTrue(Version.contains("7.4.1"));
		
	}

}

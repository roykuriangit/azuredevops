package tests;

import java.io.IOException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.response.Response;

import apiRequests.getAttachments;
import bases.baseMethods;


public class TC002_Verify_sample_attachments_are_coming_as_expected extends baseMethods {
	Response response;
	@BeforeTest
	public void setFileNameLocation() throws IOException {
	
	String url = baseMethods.url;
	if((url.contains("uat")) || (url.contains("dev"))) {
	fileName="./data/NpdTestData.xlsx";
}
	else if (url.contains("prd"))
	{
		fileName="./data/PrdTestData.xlsx";
	}
	}	

	public static Response callAttachmentsApi(String id) throws IOException
	{
		
		String url = baseMethods.url;
		String username = baseMethods.username;
		String password = baseMethods.password;
		Response response = new getAttachments()
		.getAttachmentsRequest(url, username, password,id);
		return response;
	}
	
	@Test(dataProvider ="ReadAttachmentTestData")
	public void verifyAttachmentsExists(String id, String attachmentName) throws InterruptedException
	
	{
		 try {
				response = callAttachmentsApi(id);
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			String responseOutput = response.asString();
	   	    JSONObject obj = new JSONObject(responseOutput);
	   	    String attachNamefromApi = obj.getJSONArray("results").getJSONObject(0).getString("title");
	        Assert.assertTrue(attachmentName.equals("image2014-10-2�7:31:53.png"));
	        //Assert.assertTrue(attachNamefromApi.contains(attachmentName.trim()));
	
	}
}


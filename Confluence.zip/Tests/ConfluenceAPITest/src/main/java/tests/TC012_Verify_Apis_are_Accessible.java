package tests;

import java.io.IOException;
import org.json.JSONObject;
import org.testng.annotations.Test;
import apiRequests.getUsers;
import bases.baseMethods;
import io.restassured.response.Response;
import junit.framework.Assert;

public class TC012_Verify_Apis_are_Accessible extends baseMethods{
	
	Response response;

	public static Response callGetUsersApi() throws IOException
	{
		
		String url = baseMethods.url;
		String username = baseMethods.username;
		String password = baseMethods.password;
		Response response = new getUsers()
		.getUsersRequest(url, username, password,username);
		return response;
	}
	
	@Test
	public void VerifyAPIAccessible() throws InterruptedException
	
	{
		 try {
				response = callGetUsersApi();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			String responseOutput = response.asString();
	   	    JSONObject obj = new JSONObject(responseOutput);
	   	    Assert.assertEquals(response.getStatusCode(), 200);
	        Assert.assertEquals(obj.getString("username"),username);
	
	}
}

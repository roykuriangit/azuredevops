package tests;

import org.testng.annotations.Test;

import bases.baseMethods;
import pages.LoginPage;

public class TC004_Verify_Integration_with_Jira_is_setup extends baseMethods {

	
	@Test
	public void verifyBackupRestoreEnabled()
	{
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickAdmin()
		.clickConfluenceAdmin()
		.enterPassword(password)
		.clickConfirmtoConfluenceAdmin()
		.clickApplicationLink()
		.getIntegrationDetails();
		
		
					}
	
	
}

package tests;

import java.io.IOException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import bases.baseMethods;
import pages.LoginPage;

public class TC010_Verify_Integration_with_Bamboo extends baseMethods{
	
	@BeforeTest
	public void setFileName() throws IOException {
	
	String url = baseMethods.url;
	if((url.contains("uat"))||(url.contains("dev"))) {
	fileName="./data/NpdTestData.xlsx";
}
	else if (url.contains("prd"))
	{
		fileName="./data/PrdTestData.xlsx";
	}
	}
	
	@Test(dataProvider="ReadIntegrationTestData")
	public void verifyIntegrationwithJira(String spaceDetails, String integrationDetails)
	{
		String[] spaceNameChildName = spaceDetails.split(",");
		String spaceName =spaceNameChildName[0];
		String childSpaceName =spaceNameChildName[1];
	
		
	try {
		new LoginPage()
			.enterUserName(username)
			.enterPassword(password)
			.clickLogin()
			.clickSpaces()
			.clickSpaceDirectory()
			.searchSpace(spaceName)
			.clickSpace(spaceName.split(" ")[0])
			.clickChildPage(childSpaceName)
			.clickBamboolink()
			.getCurrentUrl();
	} catch (InterruptedException e) {
		
		e.printStackTrace();
	}
		
		

	}

}

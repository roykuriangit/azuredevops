package tests;

import org.testng.annotations.Test;

import bases.baseMethods;
import pages.LoginPage;

public class TC008_Verify_confluence_is_properly_wired_up extends baseMethods{

	@Test
	public void smokeConfluenceTests() {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickSpaces()
		.clickAdmin()
		.clickAddon();
		
		
	}
}

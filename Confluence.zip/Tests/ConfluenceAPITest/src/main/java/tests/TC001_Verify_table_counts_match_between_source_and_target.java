package tests;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.microsoft.sqlserver.jdbc.SQLServerException;

import bases.baseMethods;
import utils.DatabaseConnection;

public class TC001_Verify_table_counts_match_between_source_and_target extends baseMethods {
	Connection connection;
	@BeforeTest
	public void connectToDatabase() throws IOException, SQLServerException
	
	{
		connection = DatabaseConnection.databaseConnect();
		
		String url = baseMethods.url;
		if(((url.contains("uat"))||(url.contains("dev")))) {
		fileName="./data/NpdTestData.xlsx";
	}
		else if (url.contains("prd"))
		{
			fileName="./data/PrdTestData.xlsx";
		}
		
	}
	@Test(dataProvider ="ReadSqlandCountTestData")
	public void getTableCount(String sql,String count)
	
	{
		  
	
	
		 try (Statement statement = connection.createStatement();
		            ResultSet resultSet = statement.executeQuery(sql)) {

		                // Print results from select statement
		                System.out.println("Count");
		                while (resultSet.next())
		                {
		                	 System.out.println(resultSet.getString(1));
				             Assert.assertEquals(resultSet.getString(1), count);
		                }		                
		                
		
	}
		 catch(Exception e) {
			 e.printStackTrace();
		 }
	}
	@AfterTest
	public void closeConnection() throws SQLException
	{
		 connection.close();
		
	}

}

package tests;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import org.testng.annotations.Test;



import utils.DatabaseConnection;

public class TC011_Verify_DB_Connection {
	Connection connection;
	
	@Test
	public void connectToDatabase() throws IOException, SQLException
	
	{
		connection = DatabaseConnection.databaseConnect();
        System.out.println("Schema Name:" +connection.getSchema());
        try (Statement statement = connection.createStatement();
	            ResultSet resultSet = statement.executeQuery("select count(*) from sys.tables;")) {

	                
	                while (resultSet.next())
	                {
	                	 System.out.println("Table Count:" +resultSet.getString(1));
			            
	                }	
        }
		 catch(Exception e) {
			 e.printStackTrace();
		 }
	}
}


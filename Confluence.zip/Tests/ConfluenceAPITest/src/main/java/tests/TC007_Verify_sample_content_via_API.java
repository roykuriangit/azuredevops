package tests;

import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import apiRequests.getContent;
import bases.baseMethods;
import io.restassured.response.Response;

public class TC007_Verify_sample_content_via_API extends baseMethods{

	@BeforeTest
	public void setFileName(){
		
		if(((url.contains("uat"))||(url.contains("dev")))) {
			baseMethods.fileName="./data/NpdTestData.xlsx";
	}
		else if (baseMethods.url.contains("prd"))
		{
			baseMethods.fileName="./data/PrdTestData.xlsx";
		}
	}
		
	
	
	@Test(dataProvider ="ReadSampleContentTestData")
	public void verifySampleContentExists(String contentId,String content) {
		Response response = new getContent()
				.getContentRequest(url, username, password,contentId);
		String responseOutput = response.asString();
		JSONObject obj = new JSONObject(responseOutput);
		Assert.assertEquals(obj.getString("id"), contentId);
		if(obj.getJSONObject("body").getJSONObject("view").getString("value").contains(content))
			{
			System.out.println("Content Verification is successfull");
			}
		else
			System.out.println("Content Verification is not successfull");
				
	}
	
}

package tests;



import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;




import apiRequests.getSpaces;
import bases.baseMethods;
import io.restassured.response.Response;


public class TC006_Verify_sample_site_and_personal_spaces_via_API extends baseMethods{

	
	@BeforeTest
	public void setFileName(){
		
		if(((url.contains("uat"))||(url.contains("dev")))) {
			baseMethods.fileName="./data/NpdTestData.xlsx";
	}
		else if (baseMethods.url.contains("prd"))
		{
			baseMethods.fileName="./data/PrdTestData.xlsx";
		}
	}
		
	
	
	@Test(dataProvider ="ReadSpacesandSpaceKeyTestData")
	public void verifySampleSpacesviaAPI(String spaceKey,String spaceName) {
		Response response = new getSpaces()
				.getSpacesRequest(url, username, password,spaceKey);
		String responseOutput = response.asString();
		JSONObject obj = new JSONObject(responseOutput);
		Assert.assertEquals(obj.getString("key"), spaceKey);
		Assert.assertEquals(obj.getString("name"), spaceName);
				
	}
	
}

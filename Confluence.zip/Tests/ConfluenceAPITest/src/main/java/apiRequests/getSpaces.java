package apiRequests;

import static io.restassured.RestAssured.given;

import bases.baseMethods;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class getSpaces extends baseMethods {
	
	public Response getSpacesRequest(String url,String username,String password,String spaceKey) {
		RestAssured.baseURI= url;
		Response response = null;
		response = given().auth().preemptive().basic(username, password)
		.relaxedHTTPSValidation()
		.when()
		.get("rest/api/space/"+spaceKey+"?expand=description").then().assertThat().statusCode(200).extract().response();
   		return response;
	}

}

package apiRequests;

import static io.restassured.RestAssured.given;

import bases.baseMethods;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class getAccessMode extends baseMethods {
	
	public Response getAccessModeRequest(String url,String username,String password) {
		RestAssured.baseURI= url;
		Response response = null;
		response = given().auth().preemptive().basic(username, password)
		.relaxedHTTPSValidation()
		.when()
		.get("rest/api/accessmode").then().assertThat().statusCode(200).extract().response();
   		return response;
	}

}

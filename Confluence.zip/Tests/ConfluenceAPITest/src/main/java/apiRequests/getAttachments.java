package apiRequests;

import static io.restassured.RestAssured.given;

import bases.baseMethods;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class getAttachments extends baseMethods {
	
	public Response getAttachmentsRequest(String url,String username,String password,String id) {
		RestAssured.baseURI= url;
		Response response = null;
		response = given().auth().preemptive().basic(username, password)
		.relaxedHTTPSValidation()
		.when()
		.get("rest/api/content/"+id+"/child/attachment").then().assertThat().statusCode(200).extract().response();
   		return response;
	}

}

package bases;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import org.openqa.selenium.support.ui.WebDriverWait;


import design.Browser;
import design.Element;

public class baseMethodsUi  implements Browser,Element {
	public static  RemoteWebDriver driver;
	public WebDriverWait wait;
	public static List<String> pluginsPresent;
	
	public static String url,username,password,node_total,Health,Phase,Version,chromeDriverPath;
	Properties configData = new Properties();
    
    
		public RemoteWebDriver startApp() throws IOException {
					
			FileInputStream in = new FileInputStream( "./src/main/resources/config.properties");
			configData.load(in);
			url = configData.getProperty("url");
		    username = configData.getProperty("username");
		    password = configData.getProperty("password");
		    chromeDriverPath= configData.getProperty("chromeDriverPath");
			System.setProperty("webdriver.chrome.driver", chromeDriverPath);
			ChromeOptions options = new ChromeOptions();
			//options.addArguments("--headless");
			options.setExperimentalOption("useAutomationExtension", false);
			driver = new ChromeDriver(options); 
			driver.get(url);;
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			return driver;
	}
	
	public WebElement locateElement(String locatorType, String value) {
		try
		{
			switch(locatorType.toLowerCase()) {
			case "id" : return driver.findElementById(value);
			case "name" : return driver.findElementByName(value);
			case "class" : return driver.findElementByClassName(value);
			case "link" : return driver.findElementByLinkText(value);
			case "xpath" : return driver.findElementByXPath(value);
			case "partialLink" : return driver.findElementByPartialLinkText(value);
			}
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
		
	}
	public void close() {
		driver.close();
	}
	
	public void enterValue(WebElement ele, String data) {
		
		ele.sendKeys(data);
	}
	public void click(WebElement ele) {
		try
		{
			ele.click();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public String getText(WebElement ele) {
		
		return ele.getText();
	}
	

	

	
	
	
	

}

package bases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;


import utils.ReadAttachmentTestData;
import utils.ReadIntegrationTestData;
import utils.ReadSampleContentTestData;
import utils.ReadSpacesandSpaceKey;
import utils.ReadSqlandCount;
import utils.ReadUsersTestData;

public class baseMethods extends baseMethodsUi {
	public  static String  fileName;
	
	public static String url,username,password,node_total,Health,Phase,Version;
	@BeforeSuite
	public  void getConfigData() throws IOException
	{
		Properties configData = new Properties();
		FileInputStream in = new FileInputStream( "./src/main/resources/config.properties");
		configData.load(in);
	    url = ("https://"+configData.getProperty("cfc_url").trim()+"/").replace(",", "");
	    username = configData.getProperty("username").trim().replace(",", "");
	    password = configData.getProperty("pass").trim().replace(",", "");
	   // node_total =configData.getProperty("confluence_node_num");
	   // Health =configData.getProperty("confluence_health");
	    Version =configData.getProperty("cfc_version").trim();
	 	
	}

	@DataProvider(name="ReadAttachmentTestData")	
	public String[][] sendData() throws IOException
	{
		return ReadAttachmentTestData.readAttachmentData(fileName);
	}
	
	@DataProvider(name="ReadSqlandCountTestData")	
	public String[][] sendSqlandCountData() throws IOException
	{
		return ReadSqlandCount.readSqlandCount(fileName);
	}
	
	@DataProvider(name="ReadSampleContentTestData")	
	public String[][] sendSampleContent() throws IOException
	{
		return ReadSampleContentTestData.readSampleContent(fileName);
	}
	
	@DataProvider(name="ReadUsersTestData")	
	public String[][] sendUsersData() throws IOException
	{
		return ReadUsersTestData.getUsersTestdata(fileName);
	}
	
	@DataProvider(name="ReadSpacesandSpaceKeyTestData")	
	public String[][] sendSpaceData() throws IOException
	{
		return ReadSpacesandSpaceKey.readSpacesandSpaceKey(fileName);
	}

	@DataProvider(name="ReadIntegrationTestData")	
	public String[][] sendIntegrationData() throws IOException
	{
		return ReadIntegrationTestData.readIntegrationTestData(fileName);
	}
	
	
}

package design;

import org.openqa.selenium.WebElement;

public interface Element {

	public void enterValue(WebElement ele, String data);
	public void click(WebElement ele);
}

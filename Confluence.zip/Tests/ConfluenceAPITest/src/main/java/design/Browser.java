package design;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

public interface Browser {
	
	public RemoteWebDriver startApp() throws IOException;
	public WebElement locateElement(String locatorType, String value);
	public void close();

}

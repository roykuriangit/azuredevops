function loginPageElement()
{
    this.username = element(by.id('os_username'));
    this.password = element(by.id('os_password'));
    this.login= element(by.id('loginButton'));
    this.confluenceheader = element(by.className('aui-header-logo-device'));
    this.adminTab = element(by.id('admin-menu-link'));
    this.generalConf= element(by.id('administration-link'));
    this.passwordHome = element(by.id('password'));
    this.authenticateButton= element(by.id('authenticateButton'));
    this.generalConfHeader = element(by.id('title-text'));
    this.generalConfTitle = element(by.className('admin-heading'));
    this.usersOption= element(by.id('manage-users-link'));
    this.usersConfTitle = element(by.className('admin-heading'));
    this.manageTab= element(by.id('plugin-administration-link'));
    this.manageAppTitle = element(by.className('admin-heading'));
    this.usermenu= element(by.id('user-menu-link'));
    this.logout = element(by.partialLinkText('Log Out'));
   
}

module.exports = new loginPageElement();

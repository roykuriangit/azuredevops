function homePageElement()
{
    this.confluenceheader = element(by.className('aui-header-logo-device'));
    this.spacesTab = element(by.id('space-menu-link'));
    this.spacesDirectory=  element(by.id('view-all-spaces-link'));
    this.spacesTitle = element(by.id('title-text'));
    this.peopleTab = element(by.id('people-directory-link'));
    this.peopleTitle = element(by.id('title-text'));
    this.adminTab = element(by.id('admin-menu-link'));
    this.generalConf= element(by.id('administration-link'));
    this.passwordHome = element(by.id('password'));
    this.authenticateButton= element(by.id('authenticateButton'));
    this.generalConfHeader = element(by.id('title-text'));
    this.generalConfTitle = element(by.className('admin-heading'));
    this.usersOption= element(by.id('manage-users-link'));
    this.usersConfTitle = element(by.className('admin-heading'));
    this.manageTab= element(by.id('plugin-administration-link'));
    this.manageAppTitle = element(by.className('admin-heading'));
    this.userPluginNameAll = element.all(by.xpath('//div[@id="upm-manage-container"]/div/h3[text()="User-installed add-ons"]/../div/div/div/div/div/h4'));
    this.selectPluginOptions = element(by.id('upm-manage-type'));
    this.selectSystemPlugin = element(by.cssContainingText('option', 'System')).click();;

}

module.exports = new homePageElement();
describe('smoke ui tests confluence',function(){
    const { browser, ExpectedConditions } = require("protractor");
    const loginPage = require("../Pages/login.js");
   
    var EC=protractor.ExpectedConditions;
    console.log("confluence smoke ui test started");
    
   
    it('Verify if confluence ui is properly wired and is up and running', function(){
        browser.waitForAngularEnabled(false);
        browser.get(url);
        browser.waitForAngularEnabled(false);
        browser.wait(EC.presenceOf(loginPage.username));
        loginPage.username.sendKeys(uname);
        browser.wait(EC.presenceOf(loginPage.password));
        loginPage.password.sendKeys(pwd);
        loginPage.login.click();
        browser.wait(EC.presenceOf(loginPage.confluenceheader));
        expect(loginPage.confluenceheader.getText()).toEqual('Confluence');
        loginPage.adminTab.click();
        loginPage.generalConf.click();
        loginPage.passwordHome.sendKeys(pwd);
        loginPage.authenticateButton.click();
        browser.wait(EC.presenceOf(loginPage.generalConfHeader));
        expect(loginPage.generalConfHeader.getText()).toEqual('Confluence administration');
        expect(loginPage.generalConfTitle.getText()).toEqual('General Configuration');
        loginPage.adminTab.click();
        loginPage.usersOption.click();
        browser.wait(EC.presenceOf(loginPage.usersConfTitle));
        expect(loginPage.usersConfTitle.getText()).toEqual('Users');
       // loginPage.adminTab.click();
       // loginPage.manageTab.click();
      //  browser.wait(EC.presenceOf(loginPage.manageAppTitle));
      // expect(loginPage.manageAppTitle.getText()).toEqual('Manage apps');
       loginPage.usermenu.click();
       loginPage.logout.click();
     
        
    });

});
#!/bin/bash
# Kalai: Script to get crowd app version,userdetails and hostsni
echo "Total Arguments:" $#
if [ $# == 3 ]; then
	echo "Namespace =" ${1}
    echo "value Location =" ${2}
    echo "config Location =" ${3}
else
    echo "Your command line contains wrong number of arguments"
	exit 1
fi

K8S_NAMESPACE="${1}"
FILE_LOC="${2}"
test_config_file="${3}"
TEST_USER='admin'
TEST_PASS='admin'

cfc_version=`cat ${FILE_LOC} | grep -w "tag:" | awk {'print $2'}`
echo ${cfc_version}
cfc_url=`cat ${FILE_LOC} | grep -w "TraefikSNI:" | awk {'print $2'}`
echo ${cfc_url}
echo "cfc_url:${cfc_url}," >> ${test_config_file}
echo "username:${TEST_USER}," >> ${test_config_file}
echo "pass:${TEST_PASS}," >> ${test_config_file}
echo "cfc_version:${cfc_version}," >> ${test_config_file}

